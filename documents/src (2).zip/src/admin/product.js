const MyProduct=()=>{
    return (
        <h1>product details</h1>
    )
}
export default MyProduct;
