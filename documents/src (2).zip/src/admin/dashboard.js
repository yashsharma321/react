const MyDashboard=()=>{
    return (
       <h1>dashboard</h1>
    )
}
export default MyDashboard;
