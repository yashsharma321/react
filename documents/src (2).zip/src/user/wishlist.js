
const Wishlist = () =>{
    return(
        <>
            <h1> My Wish List </h1>
        </>
    )
}

export default Wishlist;