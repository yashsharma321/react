
const UserList = (state=[], action) =>{

    var dataArray = Object.assign([], state);
    
    if(action.type==="adduser"){
        dataArray.push(action.name);
    }

    if(action.type==="deleteuser"){
        dataArray.splice(action.userindex, 1);
    }

    return dataArray;

}

export default UserList;