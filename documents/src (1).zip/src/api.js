import React,{useState, useEffect} from 'react';
import { useDispatch } from 'react-redux';

const Myapi = () =>{
    let[customerlist, updateCustomer] = useState([]);

    const getData = () =>{
        fetch("https://jsonplaceholder.typicode.com/users")
        .then(response=>response.json())
        .then(dataArray=>{
            updateCustomer(dataArray);
        })
    }

    useEffect(()=>{
        getData();
    },[1]);

    let dispatch = useDispatch();
    const save = () =>{
        let dispatchData = { type:"saveapi", alldata:customerlist};
        dispatch(dispatchData);
        alert("Data Sent To Store !");
    }

    return(
       <div className="container">
            <h1 className="text-center"> Data from Api : {customerlist.length} </h1>
            <div className="text-center m-4">
                <button className="btn btn-danger btn-lg" onClick={save}>Save in Store</button>
            </div>
            <div className="row mt-5">
                {
                    customerlist.map((customer, index)=>{
                        return(
                            <div className="col-lg-3 mb-4" key={index}>
                                <h5> {customer.name} </h5>
                                <p> {customer.email} </p>
                                <p> {customer.address.city} </p>
                            </div>
                        )
                    })
                }
            </div>
       </div>
    )
}

export default Myapi;