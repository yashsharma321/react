import React,{useState} from 'react';
import { useDispatch, useSelector } from 'react-redux';

const Mybook = () =>{
    let[name, pickName] = useState("");
    let[price, pickPrice] = useState("");
    let[qty, pickQty] = useState("");

    let dispatch = useDispatch();
    const save = () =>{
        let dispatchData = {
            type:"addbook",
            bookinfo:{name, price:price, qty:qty}
        };
        dispatch(dispatchData);
    }

    const deletebook = (index) =>{
        let dispatchData = {
            type:"deletebook",
            bookindex:index
        };
        dispatch(dispatchData);
    }

    let allbook = useSelector( state=>state.BookList );

    return(
        <div className="container mt-5">
            <div className="row">
                <div className="col-lg-12 text-center">
                    <h2> Book Management </h2>
                    <p>
                        <input type="text" className="m-3" placeholder="Enter Name"
                        onChange={obj=>pickName(obj.target.value)}/>

                        <input type="text" className="m-3" placeholder="Enter Price"
                        onChange={obj=>pickPrice(obj.target.value)}/>

                        <input type="text" className="m-3" placeholder="Enter Quantity"
                        onChange={obj=>pickQty(obj.target.value)}/>

                        <button className="btn btn-primary m-3" onClick={save}> Save Book </button>
                    </p>
                    <table className="table table-bordered">
                        <thead>
                            <tr className="bg-light text-primary">
                                <th>Sl No</th>
                                <th>Book Name</th>
                                <th>Price</th>
                                <th>Quantity</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            {
                                allbook.map((book, index)=>{
                                    return(
                                        <tr key={index}>
                                            <td> {index} </td>
                                            <td> {book.name} </td>
                                            <td> {book.price} </td>
                                            <td> {book.qty} </td>
                                            <td>
                                                <button 
                                                    className="btn btn-danger btn-sm"
                                                    onClick={deletebook.bind(this, index)}>
                                                        Delete
                                                </button>
                                            </td>
                                        </tr>
                                    )
                                })
                            }
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    )
}

export default Mybook;