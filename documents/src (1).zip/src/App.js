import { HashRouter, Routes, Route, Link } from "react-router-dom";
import MyDashboard from "./dashboard";
import Myapi from "./api";
import Myuser from "./user";
import Mybook from "./book";

function App() {
  return (
    <HashRouter>
      <div className="container mt-4">
          <div className="row">
            <div className="col-lg-4 text-center">
                <h1 className="text-primary"> React & Redux </h1>
            </div>
            <div className="col-lg-8 text-end">
                <Link className="btn btn-danger" to="/">Dashboard</Link>
                <Link className="btn btn-info" to="/user">Manage User</Link>
                <Link className="btn btn-success" to="/book">Manage Books</Link>
                <Link className="btn btn-warning" to="/api">Manage Api</Link>
            </div>
          </div>
      </div>

      <Routes>
          <Route exact path="/" element={ <MyDashboard/> } />
          <Route exact path="/user" element={ <Myuser/> } />
          <Route exact path="/book" element={ <Mybook/> } />
          <Route exact path="/api" element={ <Myapi/> } />
      </Routes>
    </HashRouter>
  );
}

export default App;
