import { useSelector } from "react-redux";

const MyDashboard = () =>{
    let alluser = useSelector( state=>state.UserList ); // fetching data from store
    let allbook = useSelector( state=>state.BookList );
    let apidata = useSelector( state=>state.ApiList );

    return(
       <div className="container mt-5">
            <div className="row">
                <div className="col-lg-12">
                    <h1 className="text-center"> Data From Redux Store </h1>
                    <table className="table table-bordered mt-5">
                        <thead>
                            <tr className="bg-light text-primary">
                                <th>Sl No</th>
                                <th>Full Name</th>
                            </tr>
                        </thead>
                        <tbody>
                            {
                                alluser.map((name, index)=>{
                                    return(
                                        <tr key={index}>
                                            <td> {index} </td>
                                            <td> {name} </td>
                                        </tr>
                                    )
                                })
                            }
                        </tbody>
                    </table>

                    <table className="table table-bordered mt-5">
                        <thead>
                            <tr className="bg-light text-primary">
                                <th>Sl No</th>
                                <th>Book Name</th>
                                <th>Price</th>
                                <th>Quantity</th>
                            </tr>
                        </thead>
                        <tbody>
                            {
                                allbook.map((book, index)=>{
                                    return(
                                        <tr key={index}>
                                            <td> {index} </td>
                                            <td> {book.name} </td>
                                            <td> {book.price} </td>
                                            <td> {book.qty} </td>
                                        </tr>
                                    )
                                })
                            }
                        </tbody>
                    </table>
                </div>
            </div>

            <div className="row mt-5">
                <div className="col-lg-12 text-center mb-5">
                    <h3> Api Data from Store : {apidata.length} </h3>
                </div>
                {
                    apidata.map((customer, index)=>{
                        return(
                            <div className="col-lg-3 mb-4" key={index}>
                                <h5> {customer.name} </h5>
                                <p> {customer.email} </p>
                                <p> {customer.address.city} </p>
                            </div>
                        )
                    })
                }
            </div>
       </div>
    )
}

export default MyDashboard;
