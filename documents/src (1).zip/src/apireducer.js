
const ApiList = (state=[], action) =>{

    var dataArray = Object.assign([], state);

    if(action.type==="saveapi"){
        dataArray = action.alldata; // assigning comple array data
    }
    return dataArray;

}

export default ApiList;