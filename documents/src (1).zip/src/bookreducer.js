
const BookList = (state=[], action) =>{

    var dataArray = Object.assign([], state);
    
    if(action.type==="addbook"){
        dataArray.push(action.bookinfo);
    }

    if(action.type==="deletebook"){
        dataArray.splice(action.bookindex, 1);
    }

    return dataArray;

}

export default BookList;