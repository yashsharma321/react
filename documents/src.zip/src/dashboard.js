
const MyDashboard = () =>{
    return(
        <h1> Dashboard </h1>
    )
}

export default MyDashboard;

// user.js   =>Myuser 
// book.js   =>Mybook 
// api.js    =>Myapi 
// dashboard.js =>MyDashboard