
const UserList = () =>{

    var dataArray = [];
    return dataArray;

}

export default UserList;