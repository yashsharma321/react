const Myapi = () =>{
    return(
        <h1> My Api </h1>
    )
}

export default Myapi;