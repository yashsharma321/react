const Mybook = () =>{
    return(
        <div className="container mt-5">
            <div className="row">
                <div className="col-lg-12 text-center">
                    <h2> Book Management </h2>
                    <p>
                        <input type="text" className="m-3" placeholder="Enter Name"/>
                        <input type="text" className="m-3" placeholder="Enter Price"/>
                        <input type="text" className="m-3" placeholder="Enter Quantity"/>
                        <button className="btn btn-primary m-3"> Save Book </button>
                    </p>
                    <table className="table table-bordered">
                        <thead>
                            <tr className="bg-light text-primary">
                                <th>Sl No</th>
                                <th>Book Name</th>
                                <th>Price</th>
                                <th>Quantity</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                    </table>
                </div>
            </div>
        </div>
    )
}

export default Mybook;