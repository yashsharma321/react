
const ApiList = () =>{

    var dataArray = [];
    return dataArray;

}

export default ApiList;