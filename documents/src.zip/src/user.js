import {useState} from 'react';

const Myuser = () =>{
    let[userlist, updateUser] = useState([]);
    let[fullname, pickName] = useState("");
    const save = () =>{
        updateUser(userlist =>[...userlist, fullname]);
    }

    return(
        <div className="container mt-5">
            <div className="row">
                <div className="col-lg-12 text-center ">
                    <h2 className="m-2"> User Management </h2>
                    Enter Full Name : <input type="text" className="m-3" 
                    onChange={obj=>pickName(obj.target.value)}/>
                    <button className="btn btn-primary m-2" onClick={save}> Save User </button>
                </div>
                <div className="col-lg-12 mt-3">
                    <table className="table table-bordered">
                        <thead>
                            <tr className="bg-light text-primary">
                                <th>Sl No</th>
                                <th>Full Name</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            {
                                userlist.map((name, index)=>{
                                    return(
                                        <tr key={index}>
                                            <td> {index} </td>
                                            <td> {name} </td>
                                            <td> --Delete-- </td>
                                        </tr>
                                    )
                                })
                            }
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    )
}

export default Myuser;