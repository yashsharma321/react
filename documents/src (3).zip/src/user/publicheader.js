
import {Link} from 'react-router-dom';

const PublicHeader=()=>{
    return (
        <ul>
            <li><Link to="/" className='myLink'>Home</Link></li>
            <li><Link to="/cart" className='myLink'>Cart</Link></li>
            <li><Link to="/wish" className='myLink'>Wish List</Link></li>
            <li><Link to="/login" className='myLink'>Login</Link></li>
        </ul>
    )
}
export default PublicHeader