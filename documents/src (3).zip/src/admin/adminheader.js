import {Link} from 'react-router-dom';

const AdminHeader=()=>{
    return (
       <ul>
            <li> <Link to="/"> dashboard </Link></li>
            <li> <Link to="/order"> Manage Orders </Link></li>
            <li> <Link to="/product"> Manage Product </Link></li>
            <li> Welcome - { localStorage.getItem("name") } </li>
            <li> <button onClick={logout}>Logout</button> </li>
       </ul>
    )
}
export default AdminHeader;

const logout = () =>{
    localStorage.clear();
    window.location.href="http://localhost:3000/#/login";
    window.location.reload();
}
